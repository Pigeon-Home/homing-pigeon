#!/usr/bin/env python3
"""Read the fuzz run log as it stood at the count of 19 November, and
split it by what a line says: a find, or nothing new.

    python3 runlog.py <clone>

Reads the clone on this machine only. Nothing is written to it.
"""
import collections, json, subprocess, sys
clone = sys.argv[1]
sys.path.insert(0, clone); sys.dont_write_bytecode = True
from runner.ops import version4
COMMIT = "0b33ac3804"
raw = subprocess.run(["git", "-C", clone, "show", COMMIT + ":runner/tests/de_dust/runs.jsonl"],
                     stdout=subprocess.PIPE, check=True).stdout.decode("utf-8")
whole = version4.count_text_tokens(raw)
lines = raw.split("\n")
if lines[-1] == "":
    lines.pop()
kinds = collections.Counter()
tok = collections.Counter()
finds = 0
by_day = collections.defaultdict(lambda: [0, 0, 0, 0])   # lines, tokens, find lines, finds
fields = collections.Counter()
big = collections.Counter()
for line in lines:
    row = json.loads(line)
    t = version4.count_text_tokens(line + "\n")
    arcs = max(0, row.get("arcs_after", 0) - row.get("arcs_before", 0))
    entries = max(0, row.get("entries_after", 0) - row.get("entries_before", 0))
    found = arcs + entries
    kind = "head" if "kind" not in row else ("find" if found else "nothing new")
    kinds[kind] += 1; tok[kind] += t; finds += found
    day = (row.get("when") or "")[:10]
    d = by_day[day]; d[0] += 1; d[1] += t; d[2] += 1 if found else 0; d[3] += found
    if kind == "nothing new":
        for k, v in row.items():
            big[k] += version4.count_text_tokens(json.dumps({k: v}))
print("the whole file: %s tokens, %s lines" % (format(whole, ","), format(len(lines), ",")))
for kind in ("find", "nothing new", "head"):
    print("  %-12s %6s lines  %12s tokens  %5.1f%% of lines  %5.1f%% of tokens" % (
        kind, format(kinds[kind], ","), format(tok[kind], ","), 100.0 * kinds[kind] / len(lines), 100.0 * tok[kind] / sum(tok.values())))
print("sum of the lines' own counts:", format(sum(tok.values()), ","))
print("finds, new arcs and new entries:", format(finds, ","))
print("tokens for each find, over the whole log: %.0f" % (whole / finds))
print("tokens for each find, in the lines that find: %.0f" % (tok["find"] / finds))
print("where the tokens of a line of nothing new go:")
for k, v in big.most_common(8):
    print("   %-18s %12s  %4.1f%%" % (k, format(v, ","), 100.0 * v / sum(big.values())))
json.dump({"whole": whole, "lines": len(lines), "kinds": dict(kinds), "tokens": dict(tok), "finds": finds,
           "by_day": {k: v for k, v in sorted(by_day.items())}}, open("runlog.json", "w"), indent=1)
