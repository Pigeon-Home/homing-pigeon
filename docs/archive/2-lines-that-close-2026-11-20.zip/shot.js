// node shot.js in.svg out.png [scale]
const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const [inp, out, scale] = process.argv.slice(2);
  const svg = fs.readFileSync(inp, 'utf8');
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 900, height: 520 }, deviceScaleFactor: Number(scale || 1) });
  await page.setContent('<html><body style="margin:0;background:#17030a">' + svg + '</body></html>');
  await page.screenshot({ path: out });
  await browser.close();
})();
