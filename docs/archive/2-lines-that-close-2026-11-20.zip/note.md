# Your drawing of 20 November: 2 lines that close

This is research, and nothing more. I did not touch the
server. I read the copy on my own machine, and I wrote
nothing to it.

## In short

- **Your idea holds.** 2 lines that close on each other pin
  1 number. Nobody has to name that number first.
- **1 line alone cannot do that.** A ceiling says "not
  above". It does not say where the count ends.
- **In whole tokens the gap does not only get small. It
  ends.** Your gap is 3,393,230 tokens. At 0.61 a week it
  is 0 after 30 weeks.
- **Your 2 lines add up to your first number.** 21.0
  million and 17.6 million are 38.6 million. With the gap
  at 0 the whole tree is 35.2 million.
- **The run log can be bent down.** 96.4% of it is lines
  that say nothing new was found.

## What I read in your drawing

- **The yellow line** is where everything but the run log
  ends: 17,606,770.
- **The red line** is where you bend the run log to. I
  took it as 21,000,000.
- **The orange bar** is the gap between the 2 lines:
  3,393,230.
- **Your words:** v5 constraints, from all directions,
  force that gap to 0 over time.

If I read 1 of these wrong, the numbers change and the
proof does not.

## The rule

Call the lower line the floor and the upper line the
ceiling. 3 things are asked, week by week.

1. The floor does not fall.
2. The ceiling does not rise.
3. The gap between them is at most 0.61 times the gap of
   the week before.

A count that is kept between the 2 lines is squeezed.

0.61 is the number the counts of everything else have kept
for 19 days. Any number under 1 gives the same proof.

## The proof, in 3 steps

**Step 1. The gap goes to 0.** After n weeks it is at most
0.61 to the power n, times the first gap. A number under
1, multiplied by itself again and again, goes to 0.

**Step 2. Each line settles.** The floor never falls and
never passes the first ceiling. So it has a limit. The
ceiling never rises and never goes under the first floor.
So it has a limit.

**Step 3. The 2 limits are 1 number.** They are never
further apart than the gap, and the gap goes to 0. A count
between the lines has nowhere else to go.

It is the theorem of nested intervals, with the squeeze
theorem for the count between. Both are in a first book of
the calculus.

## In whole tokens it arrives

Tokens are whole. A gap of whole tokens that is at most
0.61 of the last gap, rounded down, cannot stay at 1: 0.61
rounds down to 0. So the gap is exactly 0 after a number
of weeks that can be worked out first.

| After | The gap |
|------:|--------:|
| 0 weeks | 3,393,230 |
| 1 week | 2,069,870 |
| 2 weeks | 1,262,620 |
| 4 weeks | 469,820 |
| 8 weeks | 65,049 |
| 12 weeks | 9,006 |
| 20 weeks | 172 |
| 29 weeks | 1 |
| 30 weeks | 0 |

**This is what "all directions" adds.** The rule of the
curve's page pushes from 1 side: a week may add at most a
share of what is left. In whole tokens that stops short.
For your gap it stops 2 tokens short, and stays there.

Ask also that a week must close at least that share, and
it arrives: 0 is left after 30 weeks at the slowest. On
2,000 walks drawn between the least and all, the longest
took 18 weeks.

The same holds from above. A count over the line that must
lose at least a share of what it is over by comes down
onto the line, and not under it.

## Where the lines meet is a result

It depends on how hard each side pushes.

| The floor rises by | The ceiling falls by | They meet at |
|-------------------:|---------------------:|-------------:|
| nothing | 0.39 of the gap a week | 17,606,770 |
| 0.13 | 0.26 | 18,737,847 |
| 0.195 | 0.195 | 19,303,385 |
| 0.39 | nothing | 21,000,000 |

So nobody picks the limit itself. The 2 starting lines and
the 2 pushes are picked, and the limit follows from them.

## What it asks of the run log

With the floor still and the ceiling closing at 0.61 a
week:

- **This week.** The ceiling is 19,676,640 on 26 November.
  The log may add 3,357,912. Last week it added 5,767,107.
- **Next week.** The ceiling is 18,869,390 on 3 December.
  A log at the ceiling must lose 807,250.
- **In the end.** Both lines stand at 17.6 million, and
  the whole tree at 35.2 million.

So the log must lose tokens. Can it? I measured the log of
the 19 November count.

| | Lines | Tokens |
|---|------:|-------:|
| Lines that find something | 1,208 | 583,123 |
| Lines that say nothing new | 34,927 | 15,735,547 |
| The whole log, with its first line | 36,136 | 16,318,728 |

- **96.4% of the log's tokens say nothing new was found.**
- **A find costs more each week.** From 8 to 18 November
  the log wrote 10,298 tokens for each find.
- **A new reader pays at once.** 841 finds came on 19
  November alone.
- **Folded, the log is 677,562 tokens.** That keeps every
  line that finds, and 1 line of sums for each target and
  day, with 1 hash of the lines it stands for. The sums
  keep the count of inputs tried.

So the bend is there to take. It can go far lower than
your red line.

## The price

- **Your measure falls.** With the log folded the tree is
  15,632,322 tokens, where it is 31,273,488. That is
  15,641,166 less.
- **With your 2 lines instead,** the tree ends at 35.2
  million.
- **A fold can lose proof.** Each line of the log carries
  the hash of the inputs it tried. A fold keeps 1 hash for
  many lines.

## What I throw away

1. **A floor that makes the tree grow.** A rule that asks
   for tokens each week gets tokens, and not proof. The
   floor should only not fall.
2. **"The 2 lines must end equal" as a law.** I found no
   reason for it. It is your choice. A ratio between the 2
   lines would do the same work.
3. **My own line at 28.4 million.** It stood on an if that
   the log does not keep. Your bend replaces it.

## What would show this wrong

- The log adds more than 3,357,912 by 26 November, and no
  fold follows.
- A fold loses the count of inputs tried.
- Everything else passes 17,606,770. Then the floor moved,
  and the lines meet somewhere else.

## 3 numbers near your red line

I do not know which you meant. All 3 are within 0.7
million of 21.

- 20,393,230: 38 million less the yellow line.
- 20,702,733: where everything else ends if its line falls
  by 0.70 a week.
- 21,034,195: where the run log stands at most on 26
  November, by its own line.

## v4 and v5, as I read them

- **v4 holds a number from 1 side, or binds it.** A cap,
  as C1 to C4. A floor, as C6. Or exactly equal, as C5,
  C10 and C13.
- **I found 1 number in v4 held from both sides with room
  between.** A job's time, in C12: not older than 3,600
  seconds, and not more than 300 ahead.
- **A binding is a gap of 0.** So "all directions, to 0
  over time" ends where v4's bindings already stand: bound
  exactly.

This last part is my reading of the summary table of the
constraints. It is a thought, and not a count.

## What I did not do

- Nothing on the server. No push, no fold, no build.
- No suppositions were written before this measure. This
  is a note, and not a proof page.

## The files

- `check.py` works out every number here again.
- `runlog.py` and `fold.py` read the run log.
- `closing.py` draws the picture.
