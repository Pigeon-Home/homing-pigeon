#!/usr/bin/env python3
"""The owner's drawing of 20 November 2026, with numbers: 2 lines that
close on each other. Writes closing.svg beside this file.

    python3 closing.py <clone>
"""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chartbase as B   # the same drawing code as the 3 charts of 19 November
C = B.C
N = json.load(open(os.path.join(HERE, "numbers.json")))
GAPS, CEILING = N["gaps"], N["ceiling"]
RED, YELLOW, ORANGE = "#d0202c", "#ffe14a", "#ff8a2a"
FLOOR = B.REST_LIMIT
LAST, END = B.LAST, B.END

chart = B.Chart(
    "The owner's drawing of 20 November 2026 with numbers: a ceiling for the fuzz run log that starts at 21.0M and closes "
    "on the line of everything else, 17.6M. The gap between the 2 lines is 3.4M on 19 November and is multiplied by 0.61 "
    "each week",
    "2 lines that close",
    "Your drawing of 20 November, with numbers: the gap between the 2 lines, week by week",
    30e6, 5e6)

def gap_at(days):
    return GAPS[0] * 0.61 ** (days / 7.0)

chart.note("where the run log went with no bend: 28.4M, on an if")
y = chart.y_of(B.LOG_LIMIT)
chart.path("M %s %s L %d %s" % (B.n(B.x_of(LAST)), B.n(y), B.RIGHT, B.n(y)), B.AMBER, 1.2, dash="3 6")
chart.text(B.RIGHT - 6, y - 7, "28.4M: the old line, with no bend", B.DIM, 12, anchor="end")

chart.note("the yellow line: where everything else ends, 17.6M")
y = chart.y_of(FLOOR)
chart.path("M %d %s L %d %s" % (B.LEFT, B.n(y), B.RIGHT, B.n(y)), YELLOW, 2.5, cap=True)

chart.note("the red line: 21M as drawn, then closing on the yellow line")
points = [(B.LEFT, chart.y_of(21e6)), (B.x_of(LAST), chart.y_of(21e6))]
points += [(B.x_of(LAST + d), chart.y_of(FLOOR + gap_at(d))) for d in range(1, END - LAST + 1)]
chart.path(chart.line(points), RED, 3.5, cap=True, join=True)

chart.note("the gap, at each week's end: it is multiplied by 0.61 each week")
for week in range(0, 7):
    x = B.x_of(LAST + 7 * week)
    chart.path("M %s %s L %s %s" % (B.n(x), B.n(chart.y_of(FLOOR)), B.n(x), B.n(chart.y_of(CEILING[week]))), ORANGE, 6)
    label = "%.2fM" % (GAPS[week] / 1e6)
    if week == 6:
        chart.text(x - 8, chart.y_of(FLOOR) + 20, label, "#ffffff", 12.5, bold=True, anchor="end")
    else:
        chart.text(x + 6, chart.y_of(CEILING[week]) - 6, label, "#ffffff", 12.5, bold=True)

chart.note("the run log: counted, then at most the ceiling")
log_path = [(B.x_of(LAST), chart.y_of(B.LOG))]
for d in range(1, END - LAST + 1):
    free = B.allowed(B.LOG, B.LOG_COME, d)          # what its own line allows
    log_path.append((B.x_of(LAST + d), chart.y_of(min(free, FLOOR + gap_at(d)))))
chart.path(chart.line(log_path), B.AMBER, 3, dash="9 6", cap=True, join=True)

chart.note("everything else: counted, then its own rule")
chart.rule(B.REST, B.REST_COME, B.BLUE)
chart.counted(C.ELSE_BY_DAY, B.BLUE)
chart.counted(C.LOG_BY_DAY, B.AMBER, first=11)
chart.dot(B.x_of(LAST), chart.y_of(B.REST), B.BLUE)
chart.dot(B.x_of(LAST), chart.y_of(B.LOG), B.AMBER)

chart.text(90, chart.y_of(21e6) - 9, "21.0M: your red line", "#ffffff", 14, bold=True)
chart.text(90, chart.y_of(FLOOR) - 9, "17.6M: your yellow line", "#ffffff", 14, bold=True)

x = 718
chart.text(x, 122, "3.39M", "#ffffff", 17, bold=True)
chart.text(x, 139, "the gap today", B.PINK, 13)
chart.text(x, 178, "0", "#ffffff", 17, bold=True)
chart.text(x, 195, "the gap in 30 weeks,", B.PINK, 13)
chart.text(x, 211, "to the token", B.PINK, 13)
chart.text(x, 250, "17.6M", "#ffffff", 17, bold=True)
chart.text(x, 267, "where the 2 lines meet.", B.PINK, 13)
chart.text(x, 283, "Nobody names it first", B.PINK, 13)
chart.text(x, 322, "35.2M", "#ffffff", 17, bold=True)
chart.text(x, 339, "the whole tree then,", B.PINK, 13)
chart.text(x, 355, "where the 2 lines of", B.PINK, 13)
chart.text(x, 371, "today make 38.6M", B.PINK, 13)

chart.key((("line", RED, "the ceiling: it closes by 0.61 a week"),
           ("line", YELLOW, "the floor"),
           ("line", ORANGE, "the gap"),
           ("dash", B.AMBER, "the run log, bent")))
path = os.path.join(HERE, "closing.svg")
open(path, "w", encoding="utf-8").write("\n".join(chart.out + ["</svg>"]) + "\n")
print(path)
