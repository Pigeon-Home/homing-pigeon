#!/usr/bin/env python3
"""Every number of the note on the owner's drawing of 20 November 2026,
worked out again. Reads the clone on this machine. Writes nothing to it.

    python3 check.py <clone>
"""
import json, math, random, sys
from fractions import Fraction
clone = sys.argv[1]
sys.path.insert(0, clone); sys.dont_write_bytecode = True
from runner.tests import test_v4_the_curve as C

R = Fraction(61, 100)                      # what a line falls by in a week: the counts' own
(REST, REST_LIMIT), (LOG, LOG_LIMIT), (WHOLE, WHOLE_LIMIT) = C.lines()
RED = 21000000                             # the red line, as drawn
YELLOW = REST_LIMIT                        # the yellow line: 17,606,770
GAP = RED - YELLOW
out = {}

def say(name, value):
    out[name] = value
    print("%-58s %s" % (name, format(value, ",") if isinstance(value, int) else value))

say("the yellow line", YELLOW)
say("the red line, as drawn", RED)
say("the gap between them", GAP)
say("the 2 lines together", RED + YELLOW)
say("the 2 lines together when the gap is 0", 2 * YELLOW)
say("the run log today", LOG)
say("everything else today", REST)
say("the run log over everything else today", LOG - REST)

# 1. The gap, week by week, in whole tokens: each week at most 0.61 of the week before, rounded down.
gaps, gap = [GAP], GAP
while gap:
    gap = int(R * gap)
    gaps.append(gap)
say("weeks until the gap is exactly 0", len(gaps) - 1)
say("the bound: ceil(ln(gap) / ln(1/r)) + 1", math.ceil(math.log(GAP) / -math.log(float(R))) + 1)
for week in (1, 2, 3, 4, 6, 8, 12, 16, 20, 26):
    say("the gap after %2d weeks" % week, gaps[week])
say("the last week with a gap, and that gap", "%d, %d" % (len(gaps) - 2, gaps[-2]))

# 2. The ceiling for the run log, week by week, and what the log may add or must lose.
ceiling = [YELLOW + g for g in gaps]
say("the ceiling on 26 November", ceiling[1])
say("what the log may add in the week to 26 November", ceiling[1] - LOG)
say("what it added in the week to 19 November", C.LOG_BY_DAY[-1] - C.LOG_BY_DAY[-8])
say("the ceiling on 3 December", ceiling[2])
say("what the log must lose in the week to 3 December, if it stood at the ceiling", ceiling[1] - ceiling[2])
say("the whole at most on 26 November", ceiling[1] + C.stands_at_most(C.ELSE_BY_DAY, 1))

# 3. If both lines move: the floor up by a share a of the gap, the ceiling down by a share b.
def meet(a, b, floor=YELLOW, top=RED, weeks=400):
    for _ in range(weeks):
        gap = top - floor
        floor, top = floor + a * gap, top - b * gap
    return float(floor), float(top)
for a, b in ((Fraction(0), Fraction(39, 100)), (Fraction(39, 200), Fraction(39, 200)), (Fraction(13, 100), Fraction(26, 100)),
             (Fraction(39, 100), Fraction(0))):
    floor, top = meet(a, b)
    exact = YELLOW + GAP * a / (a + b)
    assert abs(floor - exact) < 1 and abs(top - exact) < 1, (a, b, floor, top, exact)
    say("floor up %s, ceiling down %s of the gap a week: they meet at" % (float(a), float(b)), int(round(exact)))

# 4. 1 direction stops short, 2 directions arrive: whole tokens.
#    v4: a week may add at most 0.39 of what is left, rounded down. v5: and must close at least 0.39, rounded up.
left, weeks = GAP, 0
while int(Fraction(39, 100) * left):
    left -= int(Fraction(39, 100) * left); weeks += 1
say("1 direction, every allowance used: it stops this many tokens short", left)
left2, weeks2 = GAP, 0
while left2:
    left2 -= math.ceil(Fraction(39, 100) * left2); weeks2 += 1
say("2 directions, the least that must be closed: weeks until 0 is left", weeks2)
draw = random.Random(2026)
worst = 0
for _ in range(2000):
    left3, n = GAP, 0
    while left3:
        least = math.ceil(Fraction(39, 100) * left3)
        left3 -= draw.randint(least, left3); n += 1
    worst = max(worst, n)
assert worst <= weeks2
say("2,000 walks drawn between the least and all: the longest took", worst)
# from above too: a count over the line, shedding at least 0.39 of what it is over by, never under the line
for start in (26735576, 28409671, 46016441):
    over, n = start - RED, 0
    while over:
        over -= draw.randint(math.ceil(Fraction(39, 100) * over), over); n += 1
    assert n <= math.ceil(math.log(start - RED) / -math.log(0.61)) + 1
say("from above, 3 starts over the line: each came down onto it", "yes")

# 5. The run log, split and folded (from runlog.py and fold.py).
log = json.load(open("runlog.json"))
say("the run log's tokens in lines of nothing new", log["tokens"]["nothing new"])
say("the run log's tokens in lines that find", log["tokens"]["find"])
say("share of the log that is lines of nothing new, %", round(100.0 * log["tokens"]["nothing new"] / log["whole"], 1))
say("finds", log["finds"])
rows, f, t = [], 0, 0
for day, (lines, tokens, find_lines, finds) in sorted(log["by_day"].items()):
    f += finds; t += tokens; rows.append((day, f, t))
by = {day: (f, t) for day, f, t in rows}
say("tokens for each find, 8 to 18 November", round((by["2026-11-18"][1] - by["2026-11-08"][1]) / (by["2026-11-18"][0] - by["2026-11-08"][0])))
say("finds on 19 November alone", by["2026-11-19"][0] - by["2026-11-18"][0])
FOLDED = 677562
say("the log folded", FOLDED)
say("the tree with the log folded", REST + FOLDED)
say("the measure would fall by", LOG - FOLDED)

# 6. 3 numbers near the red line.
say("38 million less the yellow line", 38000000 - YELLOW)
say("everything else's limit if its line fell by 0.70", math.ceil(C.by_the_rule(C.ELSE_BY_DAY, 0.70)[3]))
say("the run log at most on 26 November, by its own line", C.stands_at_most(C.LOG_BY_DAY, 1))
json.dump({"gaps": gaps, "ceiling": ceiling, "numbers": {k: (v if isinstance(v, (int, float, str)) else str(v)) for k, v in out.items()}},
          open("numbers.json", "w"), indent=1)
