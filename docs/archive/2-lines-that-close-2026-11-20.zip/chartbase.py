#!/usr/bin/env python3
"""Draw the 3 charts of 19 November again, with every limit read
off the counts by the rule of the curve's page. Nothing here is
named first: the numbers come from runner/tests/test_v4_the_curve.py.

    python3 draw.py <work folder>
"""
import math
import os
import sys

ROOT = sys.argv[1]
sys.path.insert(0, ROOT)
sys.dont_write_bytecode = True
from runner.tests import test_v4_the_curve as C  # noqa: E402

SHARE = C.A_WEEK
LAST = len(C.WHOLE_BY_DAY) - 1          # 19 November
END = 77                                # 31 December
LEFT, RIGHT, TOP, BOTTOM = 80, 704, 104, 424
BLUE, AMBER, PINK, DIM, DARK = "#3987e5", "#c98500", "#ffd7de", "#d9a9b1", "#21050b"

(REST, REST_LIMIT), (LOG, LOG_LIMIT), (WHOLE, WHOLE_LIMIT) = C.lines()
REST_COME = C.by_the_rule(C.ELSE_BY_DAY)[2]
LOG_COME = C.by_the_rule(C.LOG_BY_DAY)[2]
PACE = 4822024 / 4.0


def n(value):
    text = "%.1f" % value
    return text[:-2] if text.endswith(".0") else text


def millions(count):
    return "%.1fM" % (count / 1e6)


def x_of(day):
    return LEFT + (RIGHT - LEFT) * day / END


def allowed(stands, come, days):
    """Where a line stands at most `days` after the last count,
    with the rule kept: its limit less what is still left."""
    return stands + come * (1 - SHARE ** (days / 7.0))


class Chart:
    def __init__(self, title, heading, sub, top_value, step):
        self.top_value = top_value
        self.out = [
            '<svg xmlns="http://www.w3.org/2000/svg" width="900" height="520" '
            'viewBox="0 0 900 520" font-family="Helvetica, Arial, sans-serif">',
            "  <title>%s</title>" % title,
            "  <defs>",
            '    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">',
            '      <stop offset="0" stop-color="#2b060d"/>',
            '      <stop offset="1" stop-color="#17030a"/>',
            "    </linearGradient>",
            "  </defs>",
            '  <rect width="900" height="520" fill="url(#bg)"/>',
            '  <text x="50" y="46" fill="#ffffff" font-size="24" '
            'font-weight="bold">%s</text>' % heading,
            '  <text x="50" y="72" fill="%s" font-size="15">%s</text>' % (PINK, sub),
        ]
        self.note("the side that is not counted")
        self.out.append(
            '  <rect x="%s" y="%d" width="%s" height="%d" fill="#ffffff" '
            'fill-opacity="0.045"/>' % (n(x_of(LAST)), TOP, n(RIGHT - x_of(LAST)),
                                        BOTTOM - TOP))
        self.note("the grid and the 2 axes")
        value = 0
        while value <= top_value:
            y = self.y_of(value)
            self.path("M %d %s L %d %s" % (LEFT, n(y), RIGHT, n(y)),
                      "#6a2130" if value == 0 else "#45121d", 1)
            self.text(68, y + 4.5, "0" if value == 0 else "%dM" % (value / 1e6),
                      DIM, 13, anchor="end")
            value += step
        for day, label in ((0, "Oct 15"), (17, "Nov 1"), (LAST, "Nov 19"),
                           (47, "Dec 1"), (61, "Dec 15"), (END, "Dec 31")):
            x = n(x_of(day))
            self.path("M %s %d L %s %d" % (x, BOTTOM, x, BOTTOM + 6), "#6a2130", 1)
            self.text(x_of(day), 448, label, DIM, 13, anchor="middle")
        x = n(x_of(LAST))
        self.path("M %s %d L %s %d" % (x, TOP, x, BOTTOM), DIM, 1)
        self.text(x_of(LAST) - 12, 412, "counted", PINK, 13.5, anchor="end")
        self.text(x_of(LAST) + 12, 412, "not counted", PINK, 13.5)

    def y_of(self, count):
        return BOTTOM - (BOTTOM - TOP) * count / self.top_value

    def note(self, words):
        self.out.append("  <!-- %s -->" % words)

    def path(self, d, stroke, width, dash=None, cap=False, join=False):
        more = ""
        if dash:
            more += ' stroke-dasharray="%s"' % dash
        if join:
            more += ' stroke-linejoin="round"'
        if cap:
            more += ' stroke-linecap="round"'
        self.out.append('  <path d="%s" fill="none" stroke="%s" stroke-width="%s"%s/>'
                        % (d, stroke, n(width), more))

    def text(self, x, y, words, fill, size, bold=False, anchor=None):
        more = ' text-anchor="%s"' % anchor if anchor else ""
        if bold:
            more += ' font-weight="bold"'
        self.out.append('  <text x="%s" y="%s"%s fill="%s" font-size="%s">%s</text>'
                        % (n(x), n(y), more, fill, n(size), words))

    def dot(self, x, y, fill, radius=6.5):
        self.out.append('  <circle cx="%s" cy="%s" r="%s" fill="%s" stroke="%s" '
                        'stroke-width="2"/>' % (n(x), n(y), n(radius), fill, DARK))

    def line(self, points):
        return "M " + " L ".join("%s %s" % (n(x), n(y)) for x, y in points)

    def counted(self, series, color, first=0):
        points = [(x_of(day), self.y_of(series[day]))
                  for day in range(first, LAST + 1)]
        self.path(self.line(points), DARK, 5, join=True)
        self.path(self.line(points), color, 2.5, cap=True, join=True)

    def rule(self, stands, come, color, dash=None):
        """The line the rule draws from the last count, with a
        dot at each week's end."""
        points = [(x_of(LAST + days), self.y_of(allowed(stands, come, days)))
                  for days in range(0, END - LAST + 1)]
        self.path(self.line(points), color, 3, dash=dash, cap=True, join=True)
        for weeks in range(1, 7):
            self.dot(x_of(LAST + 7 * weeks),
                     self.y_of(allowed(stands, come, 7 * weeks)), color, 3.5)

    def limit(self, count, color, start=None):
        y = n(self.y_of(count))
        self.path("M %s %s L %d %s" % (n(LEFT if start is None else start), y,
                                       RIGHT, y),
                  color, 2, dash="7 5", cap=True)

    def pace(self, stands):
        """The last 4 days' pace, carried on unchanged to the top
        of the chart."""
        days = min(END - LAST, (self.top_value - stands) / PACE)
        self.path("M %s %s L %s %s" % (
            n(x_of(LAST)), n(self.y_of(stands)),
            n(x_of(LAST + days)), n(self.y_of(stands + PACE * days))),
            DIM, 2, dash="2 5", cap=True)

    def key(self, entries):
        x = 50
        for kind, color, words in entries:
            if kind == "dot":
                self.out.append('  <circle cx="%s" cy="489.5" r="6" fill="%s"/>'
                                % (n(x + 8), color))
                x += 24
            else:
                dash = {"line": None, "dash": "7 5", "dots": "2 5"}[kind]
                self.path("M %s 489.5 L %s 489.5" % (n(x), n(x + 28)), color, 3,
                          dash=dash, cap=True)
                x += 38
            self.text(x, 494, words, PINK, 13.5)
            x += 7.1 * len(words) + 26

    def save(self, name):
        path = os.path.join(ROOT, "assets",
                            "security-tokens-%s-2026-11-19.svg" % name)
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write("\n".join(self.out + ["</svg>"]) + "\n")
        return path


def growth():
    chart = Chart(
        "Security tokens in the tree, 15 October to 31 December 2026: counted "
        "to 19 November, then the line a rule draws from the last count toward "
        "a limit of %s that follows from the counts" % millions(WHOLE_LIMIT),
        "Security tokens in the tree",
        "Counted to 19 November 2026, then what the rule allows from the last count",
        60e6, 10e6)
    chart.note("the limit of the whole: the sum of the 2 limits the rule gives")
    chart.limit(WHOLE_LIMIT, PINK)
    chart.text(90, chart.y_of(WHOLE_LIMIT) - 10,
               "The limit that follows: %s" % millions(WHOLE_LIMIT), PINK, 14,
               bold=True)
    chart.note("the last 4 days' pace, carried on")
    chart.pace(WHOLE)
    chart.text(572, 122, "the last 4 days' pace:", PINK, 13)
    chart.text(572, 138, "past the limit", PINK, 13)
    chart.text(572, 154, "by 2 December", PINK, 13)
    chart.note("the rule: each 7 days add less than a line that falls by "
               "%s a week" % SHARE)
    chart.rule(WHOLE, REST_COME + LOG_COME, AMBER)
    chart.text(470, 236, "the rule: each 7 days add less", PINK, 13)
    chart.text(470, 252, "than a line that falls by 0.61 a week", PINK, 13)
    chart.note("the counts: each day's last landing; a ring round the first "
               "and the last")
    chart.counted(C.WHOLE_BY_DAY, BLUE)
    chart.dot(x_of(0), chart.y_of(C.WHOLE_BY_DAY[0]), BLUE)
    chart.dot(x_of(LAST), chart.y_of(WHOLE), BLUE)
    chart.text(86, chart.y_of(C.WHOLE_BY_DAY[0]) - 27,
               millions(C.WHOLE_BY_DAY[0]), "#ffffff", 15, bold=True)
    chart.text(x_of(LAST) - 12, chart.y_of(WHOLE) - 14, millions(WHOLE),
               "#ffffff", 15, bold=True, anchor="end")
    y = chart.y_of(WHOLE_LIMIT)
    chart.text(718, y - 6, millions(WHOLE_LIMIT), "#ffffff", 17, bold=True)
    chart.text(718, y + 11, "the whole: the sum", PINK, 13)
    chart.text(718, y + 27, "of the 2 limits below", PINK, 13)
    chart.text(718, y + 66, millions(REST_LIMIT), "#ffffff", 17, bold=True)
    chart.text(718, y + 83, "everything else: it has", PINK, 13)
    chart.text(718, y + 99, "kept the rule 19 days", PINK, 13)
    chart.text(718, y + 138, millions(LOG_LIMIT), "#ffffff", 17, bold=True)
    chart.text(718, y + 155, "the run log, if it keeps", PINK, 13)
    chart.text(718, y + 171, "the rule from 19 Nov", PINK, 13)
    chart.key((("dot", BLUE, "counted"),
               ("line", AMBER, "the rule, from the last count"),
               ("dash", PINK, "the limit that follows"),
               ("dots", DIM, "the last 4 days' pace")))
    return chart.save("growth")


def two_limits():
    chart = Chart(
        "The 2 parts of the security-token count, 15 October to 31 December "
        "2026: everything else under its line toward %s, and the fuzz run log "
        "toward %s if it keeps the same rule"
        % (millions(REST_LIMIT), millions(LOG_LIMIT)),
        "2 lines, 2 limits",
        "The 2 parts of the count to 19 November 2026, and the limit a rule gives each",
        30e6, 5e6)
    chart.note("the 2 limits: each follows from its own line")
    chart.limit(LOG_LIMIT, AMBER, x_of(LAST))
    chart.limit(REST_LIMIT, BLUE, x_of(LAST))
    chart.note("what the rule allows each line from 19 November: the run "
               "log's is drawn broken, because it stands on an if")
    chart.rule(LOG, LOG_COME, AMBER, dash="9 6")
    chart.rule(REST, REST_COME, BLUE)
    chart.note("the 2 lines, each day's last landing")
    chart.counted(C.ELSE_BY_DAY, BLUE)
    chart.counted(C.LOG_BY_DAY, AMBER, first=11)
    chart.dot(x_of(LAST), chart.y_of(REST), BLUE)
    chart.dot(x_of(LAST), chart.y_of(LOG), AMBER)
    y = chart.y_of(LOG_LIMIT)
    chart.text(718, y + 2, millions(LOG_LIMIT), "#ffffff", 17, bold=True)
    chart.text(718, y + 19, "the run log, if it keeps", PINK, 13)
    chart.text(718, y + 35, "the rule from 19 Nov", PINK, 13)
    y = chart.y_of(REST_LIMIT)
    chart.text(718, y + 2, millions(REST_LIMIT), "#ffffff", 17, bold=True)
    chart.text(718, y + 19, "everything else: it has", PINK, 13)
    chart.text(718, y + 35, "kept the rule 19 days", PINK, 13)
    chart.text(718, 345.2, "On 19 November", DIM, 13)
    chart.text(718, 362.2, "the run log: %s," % millions(LOG), DIM, 13)
    chart.text(718, 378.2, "and no rule kept yet.", DIM, 13)
    chart.text(718, 394.2, "Everything else: %s." % millions(REST), DIM, 13)
    chart.key((("line", AMBER, "the fuzz run log (one file)"),
               ("line", BLUE, "everything else in the tree"),
               ("dash", PINK, "the limit the rule gives")))
    return chart.save("two-limits")


def limit():
    chart = Chart(
        "Security tokens in the tree, 15 October to 31 December 2026: counted "
        "to 19 November, then the line the rule draws toward a limit of %s "
        "and the line the last 4 days' pace draws" % millions(WHOLE_LIMIT),
        "The curve and its limits",
        "Security tokens in the tree: counted to 19 November 2026, then 2 ways "
        "on from the last count",
        50e6, 10e6)
    chart.note("the limit: it follows from the rule, and nobody named it first")
    chart.limit(WHOLE_LIMIT, PINK)
    chart.text(90, chart.y_of(WHOLE_LIMIT) - 9,
               "The limit that follows: %s million" % ("%.1f" % (WHOLE_LIMIT / 1e6)),
               "#ffffff", 14, bold=True)
    chart.note("the last 4 days' pace, carried on unchanged")
    chart.pace(WHOLE)
    chart.note("the rule: each 7 days add less than a line that falls by "
               "%s a week" % SHARE)
    chart.rule(WHOLE, REST_COME + LOG_COME, AMBER)
    chart.note("the counts: each day's last landing")
    points = [(x_of(day), chart.y_of(C.WHOLE_BY_DAY[day]))
              for day in range(0, LAST + 1)]
    chart.path(chart.line(points), BLUE, 2, cap=True, join=True)
    for day in range(0, LAST + 1, 5):
        chart.dot(x_of(day), chart.y_of(C.WHOLE_BY_DAY[day]), BLUE, 4)
    chart.note("the key, and the 2 numbers of the last count")
    chart.path("M 724 150 L 748 150", BLUE, 2)
    chart.dot(736, 150, BLUE, 4)
    chart.text(756, 146, "Counted, to", "#ffffff", 13)
    chart.text(756, 162, "19 November", "#ffffff", 13)
    chart.path("M 724 200 L 748 200", AMBER, 3, cap=True)
    chart.text(756, 196, "The rule: each 7", "#ffffff", 13)
    chart.text(756, 212, "days under a line", "#ffffff", 13)
    chart.text(756, 228, "that falls by 0.61", "#ffffff", 13)
    chart.text(756, 244, "a week", "#ffffff", 13)
    chart.path("M 724 282 L 748 282", PINK, 2, dash="7 5", cap=True)
    chart.text(756, 278, "The limit that", "#ffffff", 13)
    chart.text(756, 294, "follows", "#ffffff", 13)
    chart.path("M 724 332 L 748 332", DIM, 2, dash="2 5", cap=True)
    chart.text(756, 328, "The last 4 days'", "#ffffff", 13)
    chart.text(756, 344, "pace: past the limit", "#ffffff", 13)
    chart.text(756, 360, "by 2 December", "#ffffff", 13)
    chart.text(724, 396, "Last count: %s." % format(WHOLE, ","), DIM, 12)
    chart.text(724, 414, "The weeks to come", DIM, 12)
    chart.text(724, 432, "add under %s." % format(WHOLE_LIMIT - WHOLE, ","), DIM, 12)
    chart.text(50, 488, "Each point is a day's last landing on main, by the "
               "estimator's rule. Right of 19 November nothing is counted: "
               "1 line is a rule, 1 is a pace.", DIM, 12)
    return chart.save("limit")


if __name__ == "__main__":
    for draw in (growth, two_limits, limit):
        print(draw())
