#!/usr/bin/env python3
"""What the run log of 19 November would hold if a line of nothing new
were counted and not kept: 1 line of sums for each target and day.

    python3 fold.py <clone>
"""
import collections, hashlib, json, subprocess, sys
clone = sys.argv[1]
sys.path.insert(0, clone); sys.dont_write_bytecode = True
from runner.ops import version4
raw = subprocess.run(["git", "-C", clone, "show", "0b33ac3804:runner/tests/de_dust/runs.jsonl"],
                     stdout=subprocess.PIPE, check=True).stdout.decode("utf-8")
kept, sums = [], {}
for line in raw.split("\n"):
    if not line:
        continue
    row = json.loads(line)
    found = max(0, row.get("arcs_after", 0) - row.get("arcs_before", 0)) + \
        max(0, row.get("entries_after", 0) - row.get("entries_before", 0))
    if "kind" not in row or found:
        kept.append(line)
        continue
    key = ((row.get("when") or "")[:10], row.get("target") or ",".join(row.get("targets", []))[:40], row.get("kind"))
    s = sums.setdefault(key, {"runs": 0, "tried": 0, "seconds": 0.0, "accepted": 0, "refused": 0, "crash": 0, "slow": 0,
                              "hash": hashlib.sha384()})
    s["runs"] += 1
    out = row.get("outcomes") or {}
    for k in ("accepted", "refused", "crash", "slow"):
        s[k] += out.get(k, 0) or 0
    s["tried"] += (row.get("archive") or {}).get("tried", 0) or sum((row.get("mutators_tried") or {}).values())
    s["seconds"] += row.get("seconds") or 0
    s["hash"].update(line.encode("utf-8") + b"\n")
folded = []
for (day, target, kind), s in sorted(sums.items()):
    folded.append(json.dumps({"day": day, "target": target, "kind": kind, "folded": s["runs"], "tried": s["tried"],
                              "outcomes": {k: s[k] for k in ("accepted", "refused", "crash", "slow")},
                              "seconds": round(s["seconds"], 1), "sha384": s["hash"].hexdigest()}, sort_keys=True))
count = version4.count_text_tokens
kept_tokens = sum(count(l + "\n") for l in kept)
fold_tokens = sum(count(l + "\n") for l in folded)
fold_plain = sum(count(json.dumps({k: v for k, v in json.loads(l).items() if k != "sha384"}, sort_keys=True) + "\n") for l in folded)
print("lines kept as they are (finds, and the head):", format(len(kept), ","), "lines,", format(kept_tokens, ","), "tokens")
print("lines of sums, 1 for each target, day and kind:", format(len(folded), ","), "lines,", format(fold_tokens, ","), "tokens with 1 hash each;", format(fold_plain, ","), "without the hash")
print("the folded log:", format(kept_tokens + fold_tokens, ","), "tokens, where it holds", format(count(raw), ","))
print("inputs tried, by the sums:", format(sum(s["tried"] for s in sums.values()), ","))
print("a line of sums, on average: %.0f tokens" % (fold_tokens / len(folded)))
